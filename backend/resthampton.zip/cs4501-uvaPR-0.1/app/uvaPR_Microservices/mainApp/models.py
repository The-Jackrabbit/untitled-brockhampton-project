from django.db import models
from django.db.models import Q
# Create your models here.

class User(models.Model):
	real_name = models.CharField(max_length=250)
	tag = models.CharField(max_length=250)
	profile_picture = models.ImageField(upload_to='media/users/', blank=True, null=True)
	join_date = models.DateTimeField()

	def __str__(self):
		return self.real_name
	
	def get_sets(self):
		sets = Set.objects.filter(player_one=self)
		return sets

	def get_badges(self):
		badges = BadgesToUsers.objects.filter(user=self)
		return badges

	def get_all_tags(self):
		tags = UserTags.objects.filter(user=self)
		return tags

class Season(models.Model):
	name = models.CharField(max_length=250)
	start_date = models.DateTimeField()
	end_date = models.DateTimeField()
	
	def __str__(self):
		return self.name
	
	def get_tournaments(self):
		tournaments = Tournament.objects.filter(season=self)
		return tournaments

	def get_players(self):
		tournaments = self.get_tournaments()
		players = []

		for tournament in tournaments:
			tournaments_players = tournament.get_players()
			players.extend(tournaments_players)

		players = set(players)

		return players

class Tournament(models.Model):
	date = models.DateTimeField()
	name = models.CharField(max_length=250)
	season = models.ForeignKey(Season)

	def __str__(self):
		return self.name

	def get_sets(self):
		tournament_sets = Set.objects.filter(tournament=self)
		return tournament_sets
	
	def get_players(self):
		tournament_players = TournamentToUsers.objects.filter(tournament=self)
		return tournament_players

class UserTags(models.Model):
	user = models.ForeignKey(User)
	tournament = models.ForeignKey(Tournament)
	tag = models.CharField(max_length=250)

	def __str__(self):
		return self.tag

class TournamentToUsers(models.Model):
	tournament = models.ForeignKey(Tournament)
	user = models.ForeignKey(User)

class Set(models.Model):
	victor = models.ForeignKey(User, related_name='set_victor_id', blank=True, null=True)
	tournament = models.ForeignKey(Tournament)

	child_set = models.ForeignKey('self', blank=True, null=True)

	player_one = models.ForeignKey(User, related_name='set_player_one_id')
	player_two = models.ForeignKey(User, related_name='set_player_two_id')

	def __str__(self):
		set_name = self.player_one.real_name + " vs. " + self.player_two.real_name
		return set_name

	def get_games(self):
		games = Game.objects.filter(set=self)
		return games

	def set_victor(self):
		games = self.get_games()
		wins = [0, 0]
		for game in games:
			wins[game.victor] += 1
		
		if wins[0] > wins[1]:
			self.victor = self.player_one
		elif wins[0] < wins[1]:
			self.victor = self.player_two

class Game(models.Model):
	
	VICTOR_CHOICES = (
		(0, 'Player 1'),
		(1, 'Player 2')
	)
	
	victor = models.IntegerField(
		choices=VICTOR_CHOICES
	)
	set = models.ForeignKey(Set)
	round_number = models.IntegerField(default=1, blank=True)
	
	def __str__(self):
		game_name = self.set.__str__() + " - Round " + str(self.round_number)
		return game_name

	def get_players(self):
		return {
			'player_one': self.set.player_one, 
			'player_two': self.set.player_two
		}

class PowerRank(models.Model):
	season = models.ForeignKey(Season)
	name = models.CharField(max_length=250)

	def __str__(self):
		return self.name

class PowerRankToUsers(models.Model):
	powerrank = models.ForeignKey(PowerRank)
	user = models.ForeignKey(User)
	rank = models.IntegerField()

	def __str__(self):
		return self.powerrank.__str__() + " - " + self.user.__str__() + " - " + str(self.rank)

class Badge(models.Model):
	name = models.CharField(max_length=250)
	badge_image = models.ImageField(upload_to='media/badges/', blank=True)
	points = models.IntegerField()

	def __str__(self):
		return self.name

class BadgesToUsers(models.Model):
	badge = models.ForeignKey(Badge)
	user = models.ForeignKey(User)

	def __str__(self):
		return self.user.__str__() + " - " + self.badge.name

