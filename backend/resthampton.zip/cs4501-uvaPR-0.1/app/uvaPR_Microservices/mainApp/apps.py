from django.apps import AppConfig


class UvaprAppConfig(AppConfig):
    name = 'mainApp'
