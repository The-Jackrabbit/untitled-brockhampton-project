"""uvaPR URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from mainApp import views
from rest_framework import routers


# View sets have default methods for handling GET/POST/etc, so this is explicitly overriding that
request_override_map = {
   'get': 'get',
	'post': 'post',
	'put': 'put',
	'delete': 'delete'
}
user_list = views.UserViewSet.as_view(request_override_map)
season_list = views.SeasonViewSet.as_view(request_override_map)
tournament_list = views.TournamentViewSet.as_view(request_override_map)
set_list = views.SetViewSet.as_view(request_override_map)
game_list = views.GameViewSet.as_view(request_override_map)

urlpatterns = [
	# API
	url(r'^api/v1/users/(?P<pk>[0-9]+)', user_list, name='user-detail'),
	url(r'^api/v1/users/', user_list, name='user-list'),
	url(r'^api/v1/seasons/(?P<pk>[0-9]+)', season_list, name='season-detail'),
	url(r'^api/v1/seasons/', season_list, name='season-list'),
	url(r'^api/v1/tournaments/(?P<pk>[0-9]+)', tournament_list, name='tournament-detail'),
	url(r'^api/v1/tournaments/', tournament_list, name='tournament-list'),
	url(r'^api/v1/sets/(?P<pk>[0-9]+)', set_list, name='set-detail'),
	url(r'^api/v1/sets/', set_list, name='set-list'),
	url(r'^api/v1/games/(?P<pk>[0-9]+)', game_list, name='game-detail'),
	url(r'^api/v1/games/', game_list, name='game-list'),
   url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
	# VIEWS
	url(r'^$', views.home),
   url(r'^admin/', admin.site.urls),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) +  static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) # Needed to route static files
